<?php		
//Heading
$_['heading_title']          	=	"IsellSoft Bulksync List";
$_['heading_title_parser']      =	"BulkSync Source list";
//Text
$_['text_select_parser']        =	"Choose Source";
$_['text_loading_completed']    =	"Loading Finished!";
$_['text_error_while_parsing']  =	"Error occured";
$_['text_minus']             	=	"-";
$_['text_default']           	=	"Default";
$_['text_yes']          	=	"Yes";
$_['text_no']                   =	"No";
$_['text_confirm']          	=	"Confirm *";
$_['text_all']                  =       "All";		
$_['text_last_download']        =       "Last synchronization";	
$_['text_add_parser_title']     =       "Select source and begin import";		
$_['text_was_no_download']      =       "Not synchronized yet";
$_['text_delete_parser']        =       "Delete selected source?";
$_['text_import_table']         =       "Import table";
//button
$_['button_parse']          	=	"Parse";
$_['button_parsing']          	=	"Parsing";
$_['button_parse_completed']    =	"Opening Results";
$_['button_save_prefs']         =	"Save Configuration";
$_['button_filter']		=       "Filter";
$_['button_add_parser_item']	=       "Add";
$_['button_open_parser']	=       "Open";
		


