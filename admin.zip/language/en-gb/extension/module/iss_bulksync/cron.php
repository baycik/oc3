<?php		
// Heading		
$_['heading_title']       =	"IsellSoft Bulksync Cron";
$_['heading_title_parser']=	"IsellSoft Bulksync Cron";

